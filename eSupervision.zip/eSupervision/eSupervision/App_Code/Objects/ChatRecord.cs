﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ChatRecord
/// </summary>
public class ChatRecord
{
    private string date;

    public string Date
    {
        get { return date; }
        set { date = value; }
    }
    private string time;

    public string Time
    {
        get { return time; }
        set { time = value; }
    }
    private string data;

    public string Data
    {
        get { return data; }
        set { data = value; }
    }
	public ChatRecord()
	{
		//
		// TODO: Add constructor logic here
		//
	}

}